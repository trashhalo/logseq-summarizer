# this file is necessary to disable mypy locally
# (can only be done with fully qualified namespaces)
