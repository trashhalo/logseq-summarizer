# -*- coding: utf8 -*-

from __future__ import (
    absolute_import,
    division,
    print_function,
    unicode_literals
)
import pkg_resources

__version__ = pkg_resources.get_distribution("breadability").version
